wget http://pr.willowgarage.com/data/pcl/partial_cup_model_new.pcd
mv partial_cup_model_new.pcd partial_cup_model.pcd
